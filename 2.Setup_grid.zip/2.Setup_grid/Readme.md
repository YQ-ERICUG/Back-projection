---
title: Setting grid
date: 2018-07-02T04:27:04+09:00
tags: [ "Back-projection"]
categories: [ "Back-projection manual"]
date: 2018-07-02
lastmod: 2018-07-02
---

> Here, You can understand Back-projection as the method of grid search. 
# 

First, set up enough grid ponits around epicenter, and hypothesize that every point is source location. Seismograms are stacked for each possible source location to obtain a direct image of the source. 

Then sum the energy that is radiated from the given source constructively, and cancels out other energy present in the seismograms. 

Finally, those points having largest energy make up event's rupture process.

So, the first step is arranging apposite grid net.
 

## Setting up grids

Usually, we can't make sure how many grid points and how grid points distribute are the most appropriate, so we need try many times until get a satisfied result.

`csh  Make_grid.csh`

## Look over distributions

**If needed**, we can look over distributions of stations and event(s).

`csh Figure.gmt`


***

### [Download scripts](https://github.com/YQ-ERICUG/Back-projection/blob/master/2.Setup_grid.zip)


