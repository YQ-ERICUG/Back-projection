---
title: Setting up grid
date: 2018-07-02T04:27:04+09:00
tags: [ "Back-projection"]
categories: [ "Back-projection manual"]
date: 2018-07-02
lastmod: 2018-07-05
---

> Here, you can understand Back-projection as the method of grid search. 
# 

First, set up enough grid ponits around epicenter, and hypothesize that every point is source location. Seismograms are stacked for each possible source location to obtain a direct image of the source. 

Then sum the energy that is radiated from the given source constructively, and cancels out other energy present in the seismograms. 

Finally, those points having largest energy make up event's rupture process.

So, the first step is arranging grid net.
 

## Setting up grids

Only six basic parameters are needed to set up. First, earthquake's location (longitude,latitude), whick is the base of all grid points. Then you need set up the interval between points. Last, they are number of grid ponits in four directions (along and perpendicula strike).

    set hypolon = 142.498      # epicenter's longitude
    set hypolat = 38.2963      # epicenter's latitude
    set az      = 23           # angle from north, the positive dir along strike

    set gridint = 10      # space interval between points

    set nstrike1 = 20     # no. grid points in positive dir along strike 
    set nstrike2 = 30     # no. grid points in negative dir along strike 
    set nperp1   = 10     # no. grid points eastward to hypocenter (east)
    set nperp2   = 20     # no. grid points westward to hypocenter (west)

Usually, we can't make sure how many grid points and how grid points distribute are the most appropriate, so we need try many times until get a satisfied result.

`$ csh  Make_grid.csh`

`  # open Make_grid.csh to look over all commands `

***


## Look over distributions

**If needed**, we can look over distributions of stations, grids and event(s).

`$ csh Figure.gmt`

`# open Figure.gmt to look over all commands `

![map](https://raw.githubusercontent.com/YQ-ERICUG/Back-projection/master/model1.png)

Left figure: location of 2011-03-11 M9 Tohoku earthquake and preliminary distribution of grid net; Upper right: location of seismic array in US; Lower right: overview of above information.


***

Back to [Checking data](https://yq-ericug.github.io/Checking-Data/)

Enter [Pick up model station](https://yq-ericug.github.io/Pick-up-model-station/)

***

### [Download scripts](https://github.com/YQ-ERICUG/Back-projection/blob/master/2.Setup_grid.zip)


