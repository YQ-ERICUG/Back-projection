---
title: Checking Data
date: 2018-07-02T04:27:04+09:00
tags: [ "Back-projection","Data processing"]
categories: [ "Back-projection manual"]
date: 2018-07-02
lastmod: 2018-07-02
---

> Before we start [back-projection](https://yq-ericug.github.io/Back-projection-Manual/), seismic data must be checked to avoid troubles made by data.

## Pick stations 

**If necessary**, pick stations according to azimuth and epicentral distance. Also, you can pick stations according to longitude, latitude and so on.

`   $ csh Pick_az-d.csh`

`  # open Pick_az-d.csh to look over all commands `

Change below paremeters according to your requirement:

    set a1 = 32                # azimutuh's minimum 
    set a2 = 70                # azimutuh's maximum
    set d1 = 60                # epicentral distance's minimum
    set d2 = 85                # epicentral distance's maximum


![wiber3](https://raw.githubusercontent.com/YQ-ERICUG/Back-projection/master/wiber1.png)

***

## Remove repeating stations

Sometimes, when download seismic data from [IRIS](http://ds.iris.edu/ds/) or in other way, there are two or more repeating stations occur. To avoid mistakes, we usually choose only one waveform from repeating stations (**if present**) according their names.

`$ csh Pick_repeat.csh`

`# open Pick_repeat.csh to look over all commands`

Click SAC PPK image window, if tap 'A or a' in front of 'F or f', the file will not be deleted, and if tap 'A or a' behind 'F or f', the file will be deleted.

![](https://raw.githubusercontent.com/YQ-ERICUG/Back-projection/master/check.png)

    Remove 275 stations, and now there are 512 stations
    $ csh  Pick_repeat.csh                              # Check again
    Remove 0 stations, and now there are 512 stations

***

## Check delta

Before executiving Back-projection program, it's necessary to check all data's delta to be equal. We often choose the final delta from most delta, and change other deltas into the final delta.

    $ saclst delta f *.SAC       # view delta

Here, there are three deltas(0.02,0.025,0.05). Most of them is 0.025 apparently, so we need change all deltas to 0.025.

       if (abs(dt-0.025) .gt. 0.00001) then         !dt:delta
           open(20,file='temp.csh')
            n=len_trim(file2(ista))
           if(abs(dt-0.02) .lt. 0.00001) then        !delta is 0.02_______
            write(20,*) 'echo bd sgf > sac.com'          
            write(20,*) 'echo qdp off >> sac.com'
            write(20,*) 'echo r '(1:7),file2(ista)(1:n),
     &' >> sac.com'(1:11)
            write(20,*) 'echo stretch 4 >> sac.com'   !Stretches (upsamples) data       
            write(20,*) 'echo decimate 5 >> sac.com'  !Decimates (downsamples) data 
            write(20,*) 'echo w over >> sac.com'      !overwrite headers and data
            write(20,*) 'echo quit >> sac.com' 
            write(20,*) 'sac < sac.com'
           close(20)
           call system('csh temp.csh')
           else if(abs(dt-0.05) .lt. 0.00001) then   !delta is 0.05_______
            write(20,*) 'echo bd sgf > sac.com'
            write(20,*) 'echo qdp off >> sac.com'
            write(20,*) 'echo r '(1:7),file2(ista)(1:n),
     &' >> sac.com'(1:11)
            write(20,*) 'echo stretch 2 >> sac.com'   !Stretches (upsamples) data   
            write(20,*) 'echo w over >> sac.com'   
            write(20,*) 'echo quit >> sac.com' 
            write(20,*) 'sac < sac.com'
           close(20)
           call system('csh temp.csh')
          else 
            n=len_trim(file2(ista))
            write(fin,*) 'rm '(1:3),file2(ista)(1:n)
            write(*,*) fin
            close(20)
            call system(fin)             
          end if                   
         end if

Here is only the example that we change all deltas to 0.025. It's easy to modify the script(Change_delta.f) to change deltas to other value, but remember the command order that stretch(upsamples) must be prior to decimates(downsamples).

`$ csh Change_delta.csh      `

`# open Change_delta.csh to look over all commands`

***

Enter [Setting up grid](https://yq-ericug.github.io/Setting-up-grid/)

***


### [Download scripts](https://github.com/YQ-ERICUG/Back-projection/blob/master/1.Checking_data.zip)


