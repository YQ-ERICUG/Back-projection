---
title: Checking Data
date: 2018-07-02T04:27:04+09:00
tags: [ "Back-projection","Data processing"]
categories: [ "Back-projection manual"]
date: 2018-07-02
lastmod: 2018-07-02
---

> Before we start [back-projection](https://yq-ericug.github.io/Back-projection-Manual/), seismic data must be checked to avoid troubles made by data.

## Pick stations

Pick stations according to azimuth and epicentral distance (**if necessary**). Also, you can pick stations according to longitude, latitude and so on.

`csh Pick_repeat.csh`

## Remove repeating stations

According to station's name, chose best waveform from repeating stations (**if present**).

`csh  Pick_repeat.csh`

## Check delta

Before executiving Back-projection program, it's necessary to check all data's delta to be equal. We often choose the final delta from most delta, and change other deltas into the final delta. 

Here is only the example that we change all deltas to 0.05. It's easy to modify the script to change deltas to other value, but remember the command order that stretch(upsamples) must be prior to decimates(downsamples).

`csh Change_delta.csh`

***

### [Download scripts](https://github.com/YQ-ERICUG/Back-projection/blob/master/1.Checking_data.zip)


