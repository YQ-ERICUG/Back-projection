---
title: Preprocessing in low frequency band
date: 2018-07-03T04:27:04+09:00
tags: [ "Back-projection","Data processing"]
categories: [ "Back-projection manual"]
date: 2018-07-03
lastmod: 2018-07-03
---

> Now, welcome to start key part of Back-projection. 

Copy all seismic files that have been checked, make sure there're not repeating stations and all files have an equal delta.

## Pick model station

There is only one principle that model station is the most central station among all stations.

`csh Pick_model-station.csh`

## Propress in low frequency band

We often crosse correlate waveforms in a relatively lower frequency band, and apply these obtained station corrections to the waveforms. Then, crosse correlate for higher frequency bands. This two-step procedure gives a good high-frequency station correction and avoids errors that may be caused by cycle slip in the higher frequencies.

**Steps**

1. Capture P waveforms recorded at the vertical component, from the whole waveform to avoid interference of later waves;
2. Filter with a low frequency band;
3. Align waveforms according to theoretic time interval using the 1-D global velocity model [IASPEI 1991](https://doi.org/10.1111/j.1365-246X.1991.tb06724.x);
4. Calculate cross-correlation between each station and model station using a window length;
5. Time shift according to Maximum cross-correlation and save as '.M' format.

`csh back-projection_1.csh`

***

### [Download scripts](https://github.com/YQ-ERICUG/Back-projection/blob/master/3.Back-prijection.zip)
